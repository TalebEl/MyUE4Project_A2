// Fill out your copyright notice in the Description page of Project Settings.


#include "ATEPaddle.h"


#include "Components/BoxComponent.h"


#include "PaperSpriteComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"


// Sets default values
AATEPaddle::AATEPaddle()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

#pragma region Hierarchy 2
	//1
	PlayerRootCollisionBox = CreateDefaultSubobject<UBoxComponent>("SceneRoot");
	//2
	PlayerRootCollisionBox->SetBoxExtent(FVector(120, 50, 140)); //100,10,100
	//3
	PlayerRootCollisionBox->SetSimulatePhysics(true);
	//4 
	PlayerRootCollisionBox->SetCollisionProfileName("BlockAllDynamic");
	PlayerRootCollisionBox->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	//5 - Add a Step and show camera . before 5
	PlayerRootCollisionBox->GetBodyInstance()->bLockRotation = true;// BodyInstance.bLockXRotation = true; SetConstraintMode(EDOFMode::XZPlane)
	PlayerRootCollisionBox->GetBodyInstance()->bLockXRotation = true;
	PlayerRootCollisionBox->GetBodyInstance()->bLockYRotation = true;
	PlayerRootCollisionBox->GetBodyInstance()->bLockZRotation = true;
	PlayerRootCollisionBox->GetBodyInstance()->bLockYTranslation = true;
	//6
	SetRootComponent(PlayerRootCollisionBox);

	//MISC
	//PlayerRootCollisionBox->SetEnableGravity(false);

	//OR
	//RootComponent = PlayerRoot;
	PawnSpriteComponent = CreateDefaultSubobject<UPaperSpriteComponent>("Pawn Sprite");
	PawnSpriteComponent->SetupAttachment(RootComponent);
	PawnSpriteComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	//SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraAttachmentArm"));
	//SpringArm->SetupAttachment(RootComponent);
	SpringArm->SetRelativeRotation(FRotator(0.f, -90.f, 0.f));
	SpringArm->SocketOffset = FVector(0.0f, 0.0f, 300.0f);
	SpringArm->TargetArmLength = 500.0f;
	SpringArm->bEnableCameraLag = true;
	SpringArm->CameraLagSpeed = 10.0f;
	SpringArm->bDoCollisionTest = false; //Disable Spring Arm Collision


#pragma endregion Hierarchy 2


	//NormalSpeed = 5;
	//FastSpeed = 10;
	//Speed = NormalSpeed;
}

// Called when the game starts or when spawned
void AATEPaddle::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AATEPaddle::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void AATEPaddle::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void AATEPaddle::MoveDown(float AxisValue)
{
}



void AATEPaddle::MoveUp(float AxisValue)
{
	//MovementUp = AxisValue;
	//if (SimplePawnMovementComponent && (SimplePawnMovementComponent->UpdatedComponent == RootComponent))
	//{
	//	//Move the Pawn using the SimplePawnMovementComponent on the Up Vector
	//	SimplePawnMovementComponent->AddInputVector(GetActorUpVector() * MovementUp * 1000);
	//}
	////Rotate the PawnSprite
	//if (MovementUp > 0)
	//	PawnSpriteComponent->SetRelativeRotation(FRotator(0, 0, MovementUp * 180));
	////Rotate the PawnSprite
	//if (MovementUp < 0)
	//	PawnSpriteComponent->SetRelativeRotation(FRotator(270, 0, 0));
}

void AATEPaddle::SetDirection(const FVector Direction)
{
	/*if (Direction == FVector::ForwardVector) {
		PawnSpriteComponent->SetRelativeRotation(FRotator(0, 0, 0));
	}
	else if (Direction == FVector::BackwardVector) {
		PawnSpriteComponent->SetRelativeRotation(FRotator(0, 180, 0));
	}*/
}



